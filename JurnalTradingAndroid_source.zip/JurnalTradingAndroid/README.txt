JURNAL TRADING - PROYEK ANDROID

Isi:
- Proyek Android Studio dengan WebView.
- Jurnal Trading HTML tertanam sebagai asset.
- Strategi: SNR, SND, RBS, SBR, OB, FVG.
- Data disimpan lokal di WebView/browser storage perangkat.
- Fitur ekspor CSV dan backup/impor JSON ada di aplikasi.

PENTING:
Ini adalah SOURCE PROJECT, bukan APK siap instal. APK perlu dibangun dengan Android Studio/Android SDK dan Gradle.
Cara build:
1. Ekstrak ZIP.
2. Buka folder JurnalTrading di Android Studio.
3. Tunggu Gradle sync dan unduh SDK yang diminta jika diperlukan.
4. Pilih Build > Build APK(s).
5. APK debug biasanya ada di app/build/outputs/apk/debug/app-debug.apk.

Catatan teknis:
- Aplikasi memakai WebView untuk membuka HTML lokal.
- Tidak memerlukan izin internet.
- Untuk keamanan data, gunakan Backup JSON secara berkala.
